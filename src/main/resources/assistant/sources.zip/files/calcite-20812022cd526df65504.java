/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to you under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.calcite.sql.type;

import org.apache.calcite.sql.SqlCallBinding;
import org.apache.calcite.sql.SqlNode;
import org.apache.calcite.sql.SqlUtil;

import static org.apache.calcite.util.Static.RESOURCE;

/**
 * Parameter type-checking strategy where all operand types must not be NULL.
 */
public class NotNullOperandTypeChecker extends SameOperandTypeChecker {
  //~ Instance fields --------------------------------------------------------

  private final boolean allowCast;

  //~ Constructors -----------------------------------------------------------

  public NotNullOperandTypeChecker(final int nOperands, final boolean allowCast) {
    super(nOperands);
    this.allowCast = allowCast;
  }

  //~ Methods ----------------------------------------------------------------

  @Override public boolean checkOperandTypes(final SqlCallBinding callBinding,
      final boolean throwOnFailure) {
    // no operand can be null for type-checking to succeed
    for (SqlNode node : callBinding.operands()) {
      if (SqlUtil.isNullLiteral(node, allowCast)) {
        if (throwOnFailure) {
          throw callBinding.getValidator().newValidationError(node, RESOURCE.nullIllegal());
        } else {
          return false;
        }
      }
    }
    return true;
  }
}
