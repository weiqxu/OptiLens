/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to you under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.calcite.sql.fun;

import org.apache.calcite.sql.SqlKind;
import org.apache.calcite.sql.type.SqlTypeTransforms;

/**
 * Definition of the MAP query constructor, <code>
 * MAP (&lt;query&gt;)</code>.
 *
 * <p>Like the MAP type, not standard SQL.
 */
public class SqlMapQueryConstructor extends SqlMultisetQueryConstructor {
  //~ Constructors -----------------------------------------------------------

  public SqlMapQueryConstructor() {
    super("MAP", SqlKind.MAP_QUERY_CONSTRUCTOR, SqlTypeTransforms.TO_MAP_QUERY);
  }
}
